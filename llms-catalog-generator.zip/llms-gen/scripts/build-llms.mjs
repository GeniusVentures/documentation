#!/usr/bin/env node
/**
 * build-llms.mjs — generate /llms*.txt catalogs for docs.gnus.ai
 *
 * Deterministic half of the pipeline. Run locally: `node scripts/build-llms.mjs`
 * Editorial half (descriptions, categories, sales rewrite) lives in
 * catalog-meta.json, maintained via the /update-catalogs Claude Code command.
 *
 * Zero dependencies. Node 18+.
 */

import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync } from "node:fs";
import { join, relative, extname } from "node:path";

/* ----------------------------- configuration ----------------------------- */

const CONFIG = {
  siteUrl: "https://docs.gnus.ai",
  docsDir: "docs",                    // where your markdown source lives
  outDir: "public",                   // deployed site root (wrangler serves this)
  corpusDir: "public/corpus",         // converted external docs (Drive PDFs, Google Docs)
  metaFile: "scripts/catalog-meta.json",
  exts: [".md", ".mdx"],
  exclude: [/node_modules/, /README\.md$/i, /CHANGELOG/i],
  // Public, link-shared Google Docs to mirror into the corpus.
  // Google Docs export markdown directly — no API key needed.
  googleDocs: [
    // { id: "GOOGLE_DOC_ID", out: "sales-overview.md", title: "Sales Overview" },
  ],
  // Audience files and which categories feed them. Categories are assigned
  // per-document in catalog-meta.json by the editorial pass.
  audiences: {
    "llms-sales.txt":     { title: "GNUS.ai — Sales & SMB Enablement", categories: ["sales", "product", "pricing"] },
    "llms-technical.txt": { title: "GNUS.ai — Architecture & Developer Reference", categories: ["technical", "architecture", "api", "nodes"] },
    "llms-investors.txt": { title: "GNUS.ai — Investor & JV Context", categories: ["investors", "token"] },
  },
};

/* ------------------------------- utilities ------------------------------- */

const sha = (s) => createHash("sha256").update(s).digest("hex").slice(0, 16);

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (CONFIG.exclude.some((re) => re.test(p))) continue;
    if (statSync(p).isDirectory()) walk(p, out);
    else if (CONFIG.exts.includes(extname(p))) out.push(p);
  }
  return out;
}

function frontmatter(src) {
  const m = src.match(/^---\n([\s\S]*?)\n---/);
  const fm = {};
  if (m) for (const line of m[1].split("\n")) {
    const kv = line.match(/^(\w+):\s*["']?(.*?)["']?\s*$/);
    if (kv) fm[kv[1]] = kv[2];
  }
  return fm;
}

function titleOf(src, fm, path) {
  if (fm.title) return fm.title;
  const h1 = src.match(/^#\s+(.+)$/m);
  return h1 ? h1[1].trim() : relative(CONFIG.docsDir, path);
}

const words = (s) => s.split(/\s+/).filter(Boolean).length;

/* --------------------------- gather source docs --------------------------- */

const meta = existsSync(CONFIG.metaFile) ? JSON.parse(readFileSync(CONFIG.metaFile, "utf8")) : { docs: {} };
mkdirSync(CONFIG.corpusDir, { recursive: true });

// Mirror public Google Docs into the corpus (markdown export, no API key)
for (const gd of CONFIG.googleDocs) {
  const url = `https://docs.google.com/document/d/${gd.id}/export?format=md`;
  try {
    const res = await fetch(url, { redirect: "follow" });
    if (!res.ok) throw new Error(`HTTP ${res.status} (is the doc link-shared?)`);
    const md = await res.text();
    writeFileSync(join(CONFIG.corpusDir, gd.out), md);
    console.log(`✓ fetched Google Doc → corpus/${gd.out}`);
  } catch (e) {
    console.warn(`⚠ could not fetch Google Doc ${gd.id}: ${e.message} (keeping existing copy if any)`);
  }
}

// Collect every doc: site markdown + corpus (fetched docs, converted PDFs)
const entries = [];
for (const base of [CONFIG.docsDir, CONFIG.corpusDir]) {
  if (!existsSync(base)) continue;
  for (const path of walk(base)) {
    const src = readFileSync(path, "utf8");
    const fm = frontmatter(src);
    const rel = relative(".", path).replace(/\\/g, "/");
    const inCorpus = rel.startsWith(CONFIG.corpusDir);
    const urlPath = inCorpus
      ? rel.replace(new RegExp(`^${CONFIG.outDir}/`), "/")
      : "/" + relative(CONFIG.docsDir, path).replace(/\.mdx?$/, "").replace(/\\/g, "/");
    entries.push({
      key: rel,
      url: CONFIG.siteUrl + urlPath,
      title: titleOf(src, fm, path),
      fmDescription: fm.description || null,
      hash: sha(src),
      words: words(src),
      content: src,
    });
  }
}

/* ----------------------- reconcile with catalog meta ---------------------- */

const needsEditorial = [];
for (const e of entries) {
  const m = meta.docs[e.key];
  if (!m) {
    meta.docs[e.key] = { hash: e.hash, description: e.fmDescription, category: null, optional: false, exclude: false };
    if (!e.fmDescription) needsEditorial.push({ key: e.key, reason: "new document" });
    else needsEditorial.push({ key: e.key, reason: "new document (has frontmatter description — needs category)" });
  } else if (m.hash !== e.hash) {
    m.hash = e.hash;
    m.stale = true; // description may no longer match content
    needsEditorial.push({ key: e.key, reason: "content changed — verify description/category" });
  }
}
// drop meta for deleted files
for (const key of Object.keys(meta.docs)) {
  if (!entries.find((e) => e.key === key)) delete meta.docs[key];
}
writeFileSync(CONFIG.metaFile, JSON.stringify(meta, null, 2));

/* ------------------------------ emit catalogs ----------------------------- */

const line = (e, m) => `- [${e.title}](${e.url}): ${m.description || e.fmDescription || "(no description yet)"} (${e.words} words)`;
const ready = entries.filter((e) => !meta.docs[e.key].exclude);
const byCat = (cats) => ready.filter((e) => cats.includes(meta.docs[e.key].category));

// audience files
for (const [file, cfg] of Object.entries(CONFIG.audiences)) {
  const docs = byCat(cfg.categories);
  const core = docs.filter((e) => !meta.docs[e.key].optional);
  const opt = docs.filter((e) => meta.docs[e.key].optional);
  let out = `# ${cfg.title}\n\n> Answer only from the documents below. Cite source URLs. If none apply, say so.\n\n## Documents\n\n`;
  out += core.map((e) => line(e, meta.docs[e.key])).join("\n") + "\n";
  if (opt.length) out += `\n## Optional\n\n` + opt.map((e) => line(e, meta.docs[e.key])).join("\n") + "\n";
  writeFileSync(join(CONFIG.outDir, file), out);
  console.log(`✓ ${file} (${docs.length} docs)`);
}

// master router
let master = `# GNUS.ai\n\n> GNUS.ai is a decentralized GPU processing network by Genius Ventures. `;
master += `This is the master catalog; audience-specific catalogs are linked below.\n\n## Catalogs\n\n`;
for (const [file, cfg] of Object.entries(CONFIG.audiences)) {
  master += `- [${cfg.title}](${CONFIG.siteUrl}/${file}): use for ${cfg.categories.join(", ")} questions\n`;
}
master += `- [Full corpus](${CONFIG.siteUrl}/llms-full.txt): entire documentation inlined (large)\n`;
const pinned = ready.filter((e) => meta.docs[e.key].pinned);
if (pinned.length) {
  master += `\n## Key Documents\n\n` + pinned.map((e) => line(e, meta.docs[e.key])).join("\n") + "\n";
}
writeFileSync(join(CONFIG.outDir, "llms.txt"), master);
console.log(`✓ llms.txt`);

// full corpus, inlined
const full = ready
  .map((e) => `\n\n---\nsource: ${e.url}\ntitle: ${e.title}\n---\n\n${e.content}`)
  .join("");
writeFileSync(join(CONFIG.outDir, "llms-full.txt"), `# GNUS.ai — Full Corpus\n${full}`);
console.log(`✓ llms-full.txt (${(full.length / 1024).toFixed(0)} KB)`);

/* --------------------------------- report -------------------------------- */

if (needsEditorial.length) {
  console.log(`\n${needsEditorial.length} document(s) need editorial attention:`);
  for (const n of needsEditorial) console.log(`  • ${n.key} — ${n.reason}`);
  console.log(`\nRun the /update-catalogs command in Claude Code, then re-run this script.`);
} else {
  console.log("\nAll documents have current descriptions and categories.");
}
