# Update llms.txt catalogs

Run the catalog build, then do the editorial pass it flags.

## Steps

1. Run `node scripts/build-llms.mjs` and read its report of documents needing
   editorial attention.

2. For each flagged document, read the actual source file, then edit
   `scripts/catalog-meta.json`:
   - `description`: one line, ≤ 140 chars, written for an AI agent deciding
     whether to fetch this document. State what questions it answers, not what
     it "covers". Plain, specific, no marketing tone.
   - `category`: exactly one of: sales, product, pricing, technical,
     architecture, api, nodes, token, investors. If a doc genuinely spans two,
     pick where its primary audience lives.
   - `optional: true` for reference material an agent should only fetch when
     directly relevant (doxygen-derived API references, changelogs, long
     appendices).
   - `pinned: true` for the ≤ 5 documents that belong in the master catalog's
     Key Documents section (whitepaper-tier only).
   - `exclude: true` for anything that should not be published to agents at
     all. Investor/JV material defaults to exclude unless told otherwise.
   - Remove any `stale: true` flags once you've verified or rewritten the
     description.

3. Re-run `node scripts/build-llms.mjs` and confirm it reports clean.

4. Read the generated `public/llms.txt` and each `public/llms-*.txt` top to
   bottom as if you were an external agent seeing GNUS.ai for the first time.
   Fix anything misleading, redundant, or off-tone by editing the meta file
   (never the generated output) and regenerating.

5. Show me a summary of what changed and `git diff --stat`. Do not commit —
   I review and commit the catalogs myself.

## Rules

- Never edit files in `public/llms*` directly; they are generated.
- Never invent facts about GNUS.ai — descriptions come only from what the
  source documents actually say.
- If a document's content contradicts another's, flag it to me instead of
  papering over it in the description.
